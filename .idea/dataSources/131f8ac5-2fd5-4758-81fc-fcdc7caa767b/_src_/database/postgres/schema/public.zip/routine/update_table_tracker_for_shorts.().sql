create function update_table_tracker_for_shorts() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
UPDATE table_tracker
SET last_update = NOW(), prev_update = last_update
WHERE
table_name = 'shorts' and sec_id = NEW.sec_id::TEXT;
    RETURN NEW;
END;
$$;
