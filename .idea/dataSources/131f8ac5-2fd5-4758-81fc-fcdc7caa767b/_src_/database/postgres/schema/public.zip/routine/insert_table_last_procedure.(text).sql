create function insert_table_last_procedure(i text) returns text
LANGUAGE plpgsql
AS $$
BEGIN 
    INSERT INTO table_last_time (table_id, alert_id) VALUES (1,i);
	INSERT INTO table_last_time ("table_id", "alert_id") VALUES (2,i);
END;

$$;
