CREATE VIEW max_date_sec_view AS SELECT primeview.sec_id,
    max(primeview.date) AS max
   FROM primeview
  GROUP BY primeview.sec_id;
