create function update_user_action() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
UPDATE user_action
SET last_update = CURRENT_DATE
WHERE
user_id = NEW.user_id and sec_id = NEW.sec_id::TEXT;
    RETURN NEW;
END;
$$;
