create function del_tlb() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
	DELETE FROM table_last_time WHERE alert_id = OLD.id;
	DELETE FROM alert_tracker where  user_id = OLD.owner_id and sec_id = OLD.sec_id;
RETURN OLD;
END;
$$;
