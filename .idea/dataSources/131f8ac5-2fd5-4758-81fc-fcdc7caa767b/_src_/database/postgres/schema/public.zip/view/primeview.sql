CREATE VIEW primeview AS SELECT fund_monthly.fund_id AS id,
    fund_monthly.date,
    fund_monthly.sec_id,
    (fund_monthly.manager_id)::text AS corp_id,
    NULL::text AS acquisition_date,
    fund_monthly.quantity AS par_value,
    fund_monthly.market_cap AS market_value,
    NULL::numeric AS p_afik,
    fund_monthly.percentage AS p_general,
    'fund_monthly'::text AS table_origin
   FROM fund_monthly
UNION ALL
 SELECT "מניות".id,
    "מניות".date,
    "מניות"."מספר_ניע" AS sec_id,
    "מניות"."מספר_מנפיק" AS corp_id,
    NULL::text AS acquisition_date,
    "מניות"."ערך_נקוב" AS par_value,
    "מניות"."שווי_שוק" AS market_value,
    "מניות"."שעור_מנכסי_אפיק_ההשקעה" AS p_afik,
    "מניות"."שעור_מסך_נכסי_השקעה" AS p_general,
    'מניות'::text AS table_origin
   FROM "מניות"
UNION ALL
 SELECT "אגח_קונצרני".id,
    "אגח_קונצרני".date,
    "אגח_קונצרני"."מספר_ניע" AS sec_id,
    "אגח_קונצרני"."מספר_מנפיק" AS corp_id,
    "אגח_קונצרני"."תאריך_רכישה" AS acquisition_date,
    "אגח_קונצרני"."ערך_נקוב" AS par_value,
    "אגח_קונצרני"."שווי_שוק" AS market_value,
    "אגח_קונצרני"."שעור_מנכסי_אפיק_ההשקעה" AS p_afik,
    "אגח_קונצרני"."שעור_מסך_נכסי_השקעה" AS p_general,
    'אגח_קונצרנ'::text AS table_origin
   FROM "אגח_קונצרני"
UNION ALL
 SELECT "תעודות_חוב_מסחריות_".id,
    "תעודות_חוב_מסחריות_".date,
    "תעודות_חוב_מסחריות_"."מספר_ניע" AS sec_id,
    "תעודות_חוב_מסחריות_"."מספר_מנפיק" AS corp_id,
    "תעודות_חוב_מסחריות_"."תאריך_רכישה" AS acquisition_date,
    "תעודות_חוב_מסחריות_"."ערך_נקוב" AS par_value,
    "תעודות_חוב_מסחריות_"."שווי_שוק" AS market_value,
    "תעודות_חוב_מסחריות_"."שעור_מנכסי_אפיק_ההשקעה" AS p_afik,
    "תעודות_חוב_מסחריות_"."שעור_מסך_נכסי_השקעה" AS p_general,
    'תעודות_חוב_מסחריות_'::text AS table_origin
   FROM "תעודות_חוב_מסחריות_"
UNION ALL
 SELECT "כתבי_אופציה".id,
    "כתבי_אופציה".date,
    "כתבי_אופציה"."מספר_ניע" AS sec_id,
    NULL::text AS corp_id,
    NULL::text AS acquisition_date,
    "כתבי_אופציה"."ערך_נקוב" AS par_value,
    "כתבי_אופציה"."שווי_שוק" AS market_value,
    "כתבי_אופציה"."שעור_מנכסי_אפיק_ההשקעה" AS p_afik,
    "כתבי_אופציה"."שעור_מסך_נכסי_השקעה" AS p_general,
    'כתבי_אופציה'::text AS table_origin
   FROM "כתבי_אופציה"
UNION ALL
 SELECT "תעודות_התחייבות_ממשלתיות".id,
    "תעודות_התחייבות_ממשלתיות".date,
    "תעודות_התחייבות_ממשלתיות"."מספר_ניע" AS sec_id,
    NULL::text AS corp_id,
    "תעודות_התחייבות_ממשלתיות"."תאריך_רכישה" AS acquisition_date,
    "תעודות_התחייבות_ממשלתיות"."ערך_נקוב" AS par_value,
    "תעודות_התחייבות_ממשלתיות"."שווי_שוק" AS market_value,
    "תעודות_התחייבות_ממשלתיות"."שעור_מנכסי_אפיק_ההשקעה" AS p_afik,
    "תעודות_התחייבות_ממשלתיות"."שעור_מסך_נכסי_השקעה" AS p_general,
    'תעודות_התחייבות_ממשלתיות'::text AS table_origin
   FROM "תעודות_התחייבות_ממשלתיות"
UNION ALL
 SELECT "מוצרים_מובנים".id,
    "מוצרים_מובנים".date,
    "מוצרים_מובנים"."מספר_ניע" AS sec_id,
    NULL::text AS corp_id,
    "מוצרים_מובנים"."תאריך_רכישה" AS acquisition_date,
    "מוצרים_מובנים"."ערך_נקוב" AS par_value,
    "מוצרים_מובנים"."שווי_שוק" AS market_value,
    "מוצרים_מובנים"."שעור_מנכסי_אפיק_ההשקעה" AS p_afik,
    "מוצרים_מובנים"."שעור_מסך_נכסי_השקעה" AS p_general,
    'מוצרים_מובנים'::text AS table_origin
   FROM "מוצרים_מובנים"
UNION ALL
 SELECT "קרנות_נאמנות".id,
    "קרנות_נאמנות".date,
    "קרנות_נאמנות"."מספר_ניע" AS sec_id,
    "קרנות_נאמנות"."מספר_מנפיק" AS corp_id,
    ("קרנות_נאמנות"."ערך_נקוב")::text AS acquisition_date,
    "קרנות_נאמנות"."ערך_נקוב" AS par_value,
    NULL::numeric AS market_value,
    "קרנות_נאמנות"."שעור_מנכסי_אפיק_ההשקעה" AS p_afik,
    "קרנות_נאמנות"."שעור_מסך_נכסי_השקעה" AS p_general,
    'קרנות_נאמנות'::text AS table_origin
   FROM "קרנות_נאמנות"
UNION ALL
 SELECT "תעודות_סל".id,
    "תעודות_סל".date,
    "תעודות_סל"."מספר_ניע" AS sec_id,
    "תעודות_סל"."מספר_מנפיק" AS corp_id,
    NULL::text AS acquisition_date,
    "תעודות_סל"."ערך_נקוב" AS par_value,
    "תעודות_סל"."שווי_שוק" AS market_value,
    "תעודות_סל"."שעור_מנכסי_אפיק_ההשקעה" AS p_afik,
    "תעודות_סל"."שעור_מסך_נכסי_השקעה" AS p_general,
    'תעודות_סל'::text AS table_origin
   FROM "תעודות_סל"
UNION ALL
 SELECT "לא_סחיר__מניות".id,
    "לא_סחיר__מניות".date,
    "לא_סחיר__מניות"."מספר_ניע" AS sec_id,
    "לא_סחיר__מניות"."מספר_מנפיק" AS corp_id,
    NULL::text AS acquisition_date,
    "לא_סחיר__מניות"."ערך_נקוב" AS par_value,
    "לא_סחיר__מניות"."שווי_הוגן" AS market_value,
    "לא_סחיר__מניות"."שעור_מנכסי_אפיק_ההשקעה" AS p_afik,
    "לא_סחיר__מניות"."שעור_מסך_נכסי_השקעה" AS p_general,
    'לא_סחיר__מניות'::text AS table_origin
   FROM "לא_סחיר__מניות"
UNION ALL
 SELECT "לא_סחיר_אגח_קונצרני".id,
    "לא_סחיר_אגח_קונצרני".date,
    "לא_סחיר_אגח_קונצרני"."מספר_ניע" AS sec_id,
    "לא_סחיר_אגח_קונצרני"."מספר_מנפיק" AS corp_id,
    "לא_סחיר_אגח_קונצרני"."תאריך_רכישה" AS acquisition_date,
    "לא_סחיר_אגח_קונצרני"."ערך_נקוב" AS par_value,
    "לא_סחיר_אגח_קונצרני"."שווי_הוגן" AS market_value,
    "לא_סחיר_אגח_קונצרני"."שעור_מנכסי_אפיק_ההשקעה" AS p_afik,
    "לא_סחיר_אגח_קונצרני"."שעור_מסך_נכסי_השקעה" AS p_general,
    'לא_סחיר_אגח_קונצרני'::text AS table_origin
   FROM "לא_סחיר_אגח_קונצרני"
UNION ALL
 SELECT "לא_סחיר_כתבי_אופציה".id,
    "לא_סחיר_כתבי_אופציה".date,
    "לא_סחיר_כתבי_אופציה"."מספר_ניע" AS sec_id,
    NULL::text AS corp_id,
    "לא_סחיר_כתבי_אופציה"."תאריך_רכישה" AS acquisition_date,
    "לא_סחיר_כתבי_אופציה"."ערך_נקוב" AS par_value,
    "לא_סחיר_כתבי_אופציה"."שווי_הוגן" AS market_value,
    "לא_סחיר_כתבי_אופציה"."שעור_מנכסי_אפיק_ההשקעה" AS p_afik,
    "לא_סחיר_כתבי_אופציה"."שעור_מסך_נכסי_השקעה" AS p_general,
    'לא_סחיר_אגח_קונצרני'::text AS table_origin
   FROM "לא_סחיר_כתבי_אופציה"
UNION ALL
 SELECT "לא_סחיר_מוצרים_מובנים".id,
    "לא_סחיר_מוצרים_מובנים".date,
    "לא_סחיר_מוצרים_מובנים"."מספר_ניע" AS sec_id,
    NULL::text AS corp_id,
    "לא_סחיר_מוצרים_מובנים"."תאריך_רכישה" AS acquisition_date,
    "לא_סחיר_מוצרים_מובנים"."ערך_נקוב" AS par_value,
    "לא_סחיר_מוצרים_מובנים"."שעור_מערך_נקוב_מונפק" AS market_value,
    "לא_סחיר_מוצרים_מובנים"."שעור_מנכסי_אפיק_ההשקעה" AS p_afik,
    "לא_סחיר_מוצרים_מובנים"."שעור_מסך_נכסי_השקעה" AS p_general,
    'לא_סחיר_מוצרים_מובנים'::text AS table_origin
   FROM "לא_סחיר_מוצרים_מובנים"
UNION ALL
 SELECT "לא_סחיר_תעודות_התחייבות_ממשלתי".id,
    "לא_סחיר_תעודות_התחייבות_ממשלתי".date,
    "לא_סחיר_תעודות_התחייבות_ממשלתי"."מספר_ניע" AS sec_id,
    NULL::text AS corp_id,
    "לא_סחיר_תעודות_התחייבות_ממשלתי"."תאריך_רכישה" AS acquisition_date,
    "לא_סחיר_תעודות_התחייבות_ממשלתי"."ערך_נקוב" AS par_value,
    "לא_סחיר_תעודות_התחייבות_ממשלתי"."שווי_הוגן" AS market_value,
    "לא_סחיר_תעודות_התחייבות_ממשלתי"."שעור_מנכסי_אפיק_ההשקעה" AS p_afik,
    "לא_סחיר_תעודות_התחייבות_ממשלתי"."שעור_מסך_נכסי_השקעה" AS p_general,
    'לא_סחיר_תעודות_התחייבות_ממשלתי'::text AS table_origin
   FROM "לא_סחיר_תעודות_התחייבות_ממשלתי"
UNION ALL
 SELECT "לא_סחיר_תעודות_חוב_מסחריות".id,
    "לא_סחיר_תעודות_חוב_מסחריות".date,
    "לא_סחיר_תעודות_חוב_מסחריות"."מספר_ניע" AS sec_id,
    "לא_סחיר_תעודות_חוב_מסחריות"."מספר_מנפיק" AS corp_id,
    "לא_סחיר_תעודות_חוב_מסחריות"."תאריך_רכישה" AS acquisition_date,
    "לא_סחיר_תעודות_חוב_מסחריות"."ערך_נקוב" AS par_value,
    "לא_סחיר_תעודות_חוב_מסחריות"."שווי_הוגן" AS market_value,
    "לא_סחיר_תעודות_חוב_מסחריות"."שעור_מנכסי_אפיק_ההשקעה" AS p_afik,
    "לא_סחיר_תעודות_חוב_מסחריות"."שעור_מסך_נכסי_השקעה" AS p_general,
    'לא_סחיר_תעודות_חוב_מסחריות'::text AS table_origin
   FROM "לא_סחיר_תעודות_חוב_מסחריות"
UNION ALL
 SELECT "השקעות_אחרות_".id,
    "השקעות_אחרות_".date,
    "השקעות_אחרות_"."מספר_ניע" AS sec_id,
    NULL::text AS corp_id,
    NULL::text AS acquisition_date,
    NULL::numeric AS par_value,
    "השקעות_אחרות_"."שעור_מנכסי_אפיק_ההשקעה" AS market_value,
    "השקעות_אחרות_"."שעור_מנכסי_אפיק_ההשקעה" AS p_afik,
    "השקעות_אחרות_"."שעור_מסך_נכסי_השקעה" AS p_general,
    'השקעות_אחרות_'::text AS table_origin
   FROM "השקעות_אחרות_";
