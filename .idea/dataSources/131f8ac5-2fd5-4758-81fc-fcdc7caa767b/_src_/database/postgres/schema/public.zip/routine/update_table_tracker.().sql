create function update_table_tracker() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
if TG_ARGV[0]::TEXT = '5' THEN
	UPDATE table_tracker
	SET last_update = NOW(), prev_update = last_update
	WHERE
	id = TG_ARGV[0] and 'מספר_ניע'  = NEW."מספר_ניע"::TEXT;
ELSE
	UPDATE table_tracker
	SET last_update = NOW(), prev_update = last_update
	WHERE
	id = TG_ARGV[0] and sec_id = NEW.sec_id::TEXT;
END IF;
    RETURN NEW;
END;
$$;
