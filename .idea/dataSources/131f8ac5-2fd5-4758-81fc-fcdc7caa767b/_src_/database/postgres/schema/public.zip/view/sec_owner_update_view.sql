CREATE VIEW sec_owner_update_view AS SELECT al.sec_id,
    al.owner_id,
    al.sec_name,
    b.last_check,
    tt.last_update,
    tt.prev_update,
    tt.table_name,
    b.status,
    tt.id
   FROM ((alerts al
     JOIN table_last_time b ON ((al.id = b.alert_id)))
     JOIN table_tracker tt ON (((b.table_id = tt.id) AND (al.sec_id = tt.sec_id))));
