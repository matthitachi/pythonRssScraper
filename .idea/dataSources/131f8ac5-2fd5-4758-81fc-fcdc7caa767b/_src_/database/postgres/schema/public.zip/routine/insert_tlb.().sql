create function insert_tlb() returns trigger
LANGUAGE plpgsql
AS $$
DECLARE
   counter INTEGER := 1 ; 
   counter2 INTEGER := 1 ;
BEGIN
	WHILE counter <= 5 LOOP
		INSERT INTO table_last_time (table_id, alert_id,last_check, status) VALUES (counter,NEW.id,NOW(), 'on');
		INSERT INTO table_tracker (id, last_update, prev_update, sec_id)   
		VALUES(counter , NOW(), NOW(), NEW.sec_id)
		ON 
		CONFLICT (id, sec_id)
		DO NOTHING
		;
		
		counter := counter + 1 ; 
END LOOP ; 
WHILE counter2 <= 9 LOOP
		INSERT INTO alert_tracker VALUES(NEW.owner_id, NEW.sec_id, counter2, 'on' );
		counter2 := counter2 + 1 ; 
END LOOP ; 

RETURN NEW;
END;
$$;
