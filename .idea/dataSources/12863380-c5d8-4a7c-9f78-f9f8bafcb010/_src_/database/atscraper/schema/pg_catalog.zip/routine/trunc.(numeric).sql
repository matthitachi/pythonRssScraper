create function pg_catalog.trunc(numeric) returns numeric
LANGUAGE SQL
AS $$
select pg_catalog.trunc($1,0)
$$;
